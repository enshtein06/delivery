import React from 'react';


export default ({children}) => {
	return (
		<div>{children}</div>
	);
};